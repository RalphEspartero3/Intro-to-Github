<div class="card">
    <div class="carousel-wrapper">
        <div class="carousel">
            <img src="assets images/images/home1.jpeg">
            <img src="assets images/images/home2.jpeg">
            <img src="assets images/images/home3.jpeg">
            <img src="assets images/images/home4.jpeg">
        </div>
    </div>
    
    <section class="hero">
        <div class="hero-content">
            <h1><?php echo $heroTitle; ?></h1> <p><?php echo $heroSubtitle; ?></p>
            <a href="reservation.php" class="btn-primary">Book Your Stay Now</a>
        </div>
    </section>

    </div>
<style>
       body {
            font-family: 'Segoe UI', sans-serif;
            background: #2c3e50;
        }
        h1 {
            color: #2ecc71;
            font-size: 3rem;
            margin-bottom: 10px;
            font-weight: 700;
        }
        p {
            color: #bdc3c7;
            font-size: 1.2rem;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        .btn-book {
            display: inline-block;
            text-decoration: none;
            background: #2ecc71;
            color: white;
            padding: 15px 35px;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(46, 204, 113, 0.3);
        }
        .btn-book:hover {
            background: #27ae60;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 204, 113, 0.5);
        }
        .admin-link {
            display: block;
            margin-top: 40px;
            color: #7f8c8d;
            text-decoration: none;
            font-size: 0.9rem;
            transition: 0.3s;
        }
        .admin-link:hover {
            color: #bdc3c7;
        }
</style>