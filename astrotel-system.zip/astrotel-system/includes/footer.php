</div>

<footer class="footer">

    <div class="footer-container">
        <div class="footer-col">
            <h3>For Room Reservation</h3>
            <p><strong>0998-510-1000</strong></p>
        </div>
        <div class="footer-col">
            <h3>ASTROTEL HOTEL</h3>
            <p>Make every experience unique as we give you a space of your own. Make Astrotel your go-to place today.</p>
            <p><strong>Address:</strong> 629 EDSA Cubao, Quezon City</p>
            <p><strong>Email:</strong> inquiry.astrotel@astrotel.ph</p>
        </div>
        <div class="footer-col">
            <h3>Get in Touch</h3>
            <p>629 EDSA Cubao, Quezon City</p>
            <p>roomreservations@astrotel.ph</p>
        </div>
        <div class="footer-col">
            <h3>News and Updates</h3>

            <p><strong>ASTROTEL named Best Modern Thematic Budget Hotel</strong></p>
            <p style="font-size:13px;">
                ASTROTEL, the growing hotel chain in Metro Manila, recently won the Best Modern Thematic Budget Hotel at the 4th Global Awards for Marketing & Business Excellence held at the Grand Ballroom of Manila Marriott Hotel...
            </p>
            <p style="color:#2ecc71;"><strong>Read More</strong> - Oct 10, 2022</p>

            <hr>

            <p><strong>Model Linda Jean Renews Contract With Astrotel</strong></p>
            <p style="font-size:13px;">MANILA, Philippines – Astrotel continues to expand...</p>
        </div>

    </div>

</footer>

</body>
</html>