<!DOCTYPE html>
<html>
<head>
<title>Astrotel Reservation System</title>
<link rel="stylesheet" href="/astrotel-system/assets css/css/style.css">
<header>
    <nav class="navbar">
        <a href="index.php" class="logo-link">
            <img src="/astrotel-system/assets images/icons/icon.png" class="main-logo">
        </a>
        
        <ul class="nav-links">
            <li><a href="index.php">HOME</a></li>
            <li><a href="profile.php">PROFILE</a></li>
            <li><a href="reservation.php">RESERVATION</a></li>
            <li><a href="contacts.php">CONTACTS</a></li>
        </ul>
    </nav>
</header>