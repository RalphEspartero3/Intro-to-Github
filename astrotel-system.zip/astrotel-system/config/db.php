<?php
$conn = new PDO("mysql:host=localhost;dbname=astrotel_db", "root", "");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>