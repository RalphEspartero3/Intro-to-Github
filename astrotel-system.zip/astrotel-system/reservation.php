<?php 
include 'config/db.php'; 
if (isset($_POST['book_now'])) {
    $name = $_POST['fullname'];
    $email = $_POST['email'];
    $room_id = $_POST['room_id'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $payment = $_POST['payment'];

    $sql = "INSERT INTO reservations (fullname, email, room_id, checkin, checkout, payment, total, status) 
            VALUES (?, ?, ?, ?, ?, ?, 0, 'Pending')";
    
    $conn->prepare($sql)->execute([$name, $email, $room_id, $checkin, $checkout, $payment]);
    $success = "Booking request sent! Please wait for admin approval.";
}
$available_rooms = $conn->query("SELECT * FROM rooms WHERE status = 'Available'")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Book Your Stay | Astrotel</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #2c3e50; color: white; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .booking-card { background: white; color: #333; padding: 40px; border-radius: 15px; width: 100%; max-width: 450px; box-shadow: 0 10px 30px rgba(0,0,0,0.3); position: relative;}
        h2 { text-align: center; color: #2ecc71; margin-bottom: 30px; margin-top: 10px; }
        input, select { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; }
        .btn-book { width: 100%; background: #2ecc71; color: white; border: none; padding: 15px; border-radius: 8px; font-size: 1.1em; font-weight: bold; cursor: pointer; transition: 0.3s; margin-top: 10px; }
        .btn-book:hover { background: #27ae60; }
        .alert { background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; text-align: center; }
        
        /* Back Button Styling */
        .back-btn { text-decoration: none; color: #7f8c8d; font-weight: bold; font-size: 0.9em; transition: 0.3s; display: inline-block; margin-bottom: 15px; }
        .back-btn:hover { color: #2c3e50; }
    </style>
</head>
<body>

<div class="booking-card">
    <a href="index.php" class="back-btn">← Back to Home</a>
    
    <h2>Astrotel Booking</h2>
    
    <?php if(isset($success)): ?>
        <div class="alert"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="fullname" placeholder="Your Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        
        <label style="font-size: 0.9em; color: #666;">Select Room:</label>
        <select name="room_id" required>
            <?php foreach($available_rooms as $room): ?>
                <option value="<?= $room['id'] ?>">
                    <?= $room['room_name'] ?> - <?= $room['room_type'] ?> (₱<?= number_format($room['price_per_night']) ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <div style="display: flex; gap: 10px;">
            <div style="flex: 1;">
                <label style="font-size: 0.8em; color: #666;">Check-in:</label>
                <input type="date" name="checkin" required>
            </div>
            <div style="flex: 1;">
                <label style="font-size: 0.8em; color: #666;">Check-out:</label>
                <input type="date" name="checkout" required>
            </div>
        </div>

        <select name="payment">
            <option>Cash at Counter</option>
            <option>GCash / PayMaya</option>
            <option>Credit Card</option>
        </select>

        <button type="submit" name="book_now" class="btn-book">Confirm Reservation</button>
    </form>
</div>

</body>
</html>