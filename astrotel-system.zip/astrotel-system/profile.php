<?php
// 1. Connection & Model Setup
require_once 'config/db.php';
require_once 'models/RoomModel.php';

// 2. Data Fetching
$roomModel = new RoomModel($conn);
$rooms = $roomModel->getFeaturedRooms();

// 3. View Rendering
include 'includes/header.php';
?>

<div class="rooms-grid">
    <?php foreach ($rooms as $room): ?>
        <div class="section">
            <img src="assets images/images/<?php echo $room['room_image']; ?>" alt="Room Image">
            
            <p><?php echo $room['room_type']; ?></p>
        </div>
    <?php endforeach; ?>
</div>

<?php include 'includes/footer.php'; ?>