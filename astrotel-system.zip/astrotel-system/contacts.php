<?php include 'includes/header.php'; ?>

<div class="card">

    <h2>Contact Astrotel</h2>
    <p style="margin-bottom:15px;">We’d love to hear from you. Reach out using the details below.</p>

    <hr style="margin:15px 0;">

    <p><strong>Email:</strong> inquiry.astrotel@astrotel.ph</p>
    <p><strong>Phone:</strong> 0998-510-1000</p>
    <p><strong>Location:</strong> 629 EDSA Cubao, Quezon City</p>

    <hr style="margin:20px 0;">

    <h3>Send us a Message</h3>

    <form method="POST">

        <input type="text" name="name" placeholder="Your Name" required>

        <input type="email" name="email" placeholder="Your Email" required>

        <input type="text" name="subject" placeholder="Subject" required>

        <textarea name="message" placeholder="Your Message" rows="4" 
        style="width:100%;margin-top:10px;padding:10px;border-radius:8px;border:1px solid #ccc;"></textarea>

        <button type="submit" name="send">Send Message</button>

    </form>

    <?php
    if(isset($_POST['send'])){
        echo "<p style='margin-top:15px;color:green;'>Message sent successfully! (Demo only)</p>";
    }
    ?>

</div>

<?php include 'includes/footer.php'; ?>