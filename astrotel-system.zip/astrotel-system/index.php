<?php
require_once 'config/db.php';
require_once 'models/RoomModel.php';

// 1. Get Data from Model
$roomModel = new RoomModel($conn);
$rooms = $roomModel->getFeaturedRooms();

// 2. Set UI Variables
$heroTitle = "Welcome to Astrotel";
$heroSubtitle = "Experience stellar comfort...";

// 3. Load the Views
include 'includes/header.php';
include 'views/home_view.php'; 
include 'includes/footer.php';
?>