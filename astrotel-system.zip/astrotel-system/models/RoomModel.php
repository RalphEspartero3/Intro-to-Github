<?php
// models/RoomModel.php
class RoomModel {
    private $db;

    public function __construct($database_connection) {
        $this->db = $database_connection;
    }
public function getFeaturedRooms() {
    // Correct PDO syntax:
    $query = "SELECT id, room_name, room_type, room_image FROM rooms"; 
    $stmt = $this->db->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
}