<?php 
include '../config/db.php'; 
include 'admin_header.php'; 
if (isset($_POST['add_room'])) {
    $name = $_POST['room_name'];
    $type = $_POST['room_type'];
    $price = $_POST['price'];
    
    $sql = "INSERT INTO rooms (room_name, room_type, price_per_night, status) VALUES (?, ?, ?, 'Available')";
    $conn->prepare($sql)->execute([$name, $type, $price]);
    header("Location: rooms.php"); exit();
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->prepare("DELETE FROM rooms WHERE id = ?")->execute([$id]);
    header("Location: rooms.php"); exit();
}

$rooms = $conn->query("SELECT * FROM rooms ORDER BY id DESC")->fetchAll();
?>

<div class="admin-content">
    <h2>Room Management</h2>

    <div style="background: #fff; padding: 20px; border-radius: 12px; margin-bottom: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
        <h4 style="margin-top:0;">Add New Room</h4>
        <form method="POST" style="display: flex; gap: 10px; flex-wrap: wrap;">
            <input type="text" name="room_name" placeholder="Room # (e.g. 105)" required style="padding:10px; flex:1; border:1px solid #ddd; border-radius:5px;">
            <select name="room_type" style="padding:10px; flex:1; border:1px solid #ddd; border-radius:5px;">
                <option>Deluxe Room</option>
                <option>Premium Room</option>
                <option>VIP Room</option>
                <option>Themed Room</option>
            </select>
            <input type="number" name="price" placeholder="Price per Night" required style="padding:10px; flex:1; border:1px solid #ddd; border-radius:5px;">
            <button name="add_room" type="submit" class="btn btn-approve">+ Add Room</button>
        </form>
    </div>

    <table class="admin-table">
        <tr>
            <th>Room</th>
            <th>Type</th>
            <th>Price</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php foreach($rooms as $r): ?>
        <tr>
            <td><strong><?= htmlspecialchars($r['room_name']) ?></strong></td>
            <td><?= htmlspecialchars($r['room_type']) ?></td>
            <td>₱<?= number_format($r['price_per_night'], 2) ?></td>
            <td>
                <span class="status-badge status-<?= ($r['status'] == 'Available') ? 'Approved' : 'Rejected' ?>">
                    <?= $r['status'] ?>
                </span>
            </td>
            <td>
                <a href="rooms.php?delete=<?= $r['id'] ?>" 
                   onclick="return confirm('Delete this room?')" 
                   style="color: #e74c3c; text-decoration: none; font-weight: bold;">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>