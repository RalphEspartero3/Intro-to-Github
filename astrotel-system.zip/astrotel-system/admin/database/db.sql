CREATE DATABASE IF NOT EXISTS astrotel_db;
USE astrotel_db;

CREATE TABLE IF NOT EXISTS rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_name VARCHAR(100) NOT NULL,
    room_type VARCHAR(50) NOT NULL,
    price_per_night DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'Available'
);

CREATE TABLE IF NOT EXISTS reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    room_id INT NOT NULL, 
    checkin DATE NOT NULL,
    checkout DATE NOT NULL,
    payment VARCHAR(50) NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'Pending',
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
);

-- Fresh Starter Data
INSERT INTO rooms (room_name, room_type, price_per_night, status) VALUES 
('101', 'Deluxe Room', 2500.00, 'Available'),
('102', 'Premium Room', 3500.00, 'Available'),
('103', 'VIP Room', 5000.00, 'Available'),
('104', 'Captain America Room', 6000.00, 'Available');