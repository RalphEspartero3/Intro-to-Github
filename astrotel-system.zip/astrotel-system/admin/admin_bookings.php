<?php 
include '../config/db.php'; 
include 'admin_header.php'; 

if(isset($_POST['action'])) {
    $res_id = $_POST['res_id'];
    $room_id = $_POST['room_id'];
    $status = ($_POST['action'] == 'approve') ? 'Approved' : 'Rejected';
    $conn->prepare("UPDATE reservations SET status = ? WHERE id = ?")->execute([$status, $res_id]);
    if($status == 'Approved') {
        $conn->prepare("UPDATE rooms SET status = 'Booked' WHERE id = ?")->execute([$room_id]);
    }
    header("Location: admin_bookings.php");
    exit();
}
$query = "SELECT r.*, rm.room_name, rm.room_type 
          FROM reservations r 
          JOIN rooms rm ON r.room_id = rm.id 
          ORDER BY r.id DESC";

$bookings = $conn->query($query)->fetchAll();
?>

<div class="admin-content">
    <h2>Manage Bookings</h2>
    
    <table class="admin-table">
        <tr>
            <th>Guest</th>
            <th>Room #</th>
            <th>Room Type</th>
            <th>Check-in</th>
            <th>Check-out</th> <th>Status</th>
            <th>Actions</th>
        </tr>
        
        <?php foreach($bookings as $b): ?>
        <tr>
            <td><?= htmlspecialchars($b['fullname']) ?></td>
            <td><?= htmlspecialchars($b['room_name']) ?></td>
            <td><?= htmlspecialchars($b['room_type']) ?></td>
            <td><?= $b['checkin'] ?></td>
            <td><?= $b['checkout'] ?></td> <td><span class="status-badge status-<?= $b['status'] ?>"><?= $b['status'] ?></span></td>
            <td>
                <?php if($b['status'] == 'Pending'): ?>
                <form method="POST" style="display:inline">
                    <input type="hidden" name="res_id" value="<?= $b['id'] ?>">
                    <input type="hidden" name="room_id" value="<?= $b['room_id'] ?>">
                    
                    <button name="action" value="approve" class="btn btn-approve">Approve</button>
                    <button name="action" value="reject" class="btn btn-reject">Reject</button>
                </form>
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        
    </table>
</div>

</body>
</html>