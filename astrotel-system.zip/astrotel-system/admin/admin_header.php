<!DOCTYPE html>
<html>
<head>
    <title>Astrotel Admin</title>
    <style>
        :root { --green: #2ecc71; --dark: #2c3e50; --bg: #f4f7f6; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; }
        .admin-nav { background: #fff; padding: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); border-bottom: 1px solid #ddd; }
        .nav-container { display: flex; justify-content: center; gap: 30px; }
        .nav-container a { text-decoration: none; color: #555; font-weight: bold; padding: 10px 15px; border-radius: 5px; transition: 0.3s; }
        .nav-container a:hover, .nav-container a.active { background: var(--green); color: #fff; }
        
        .admin-content { max-width: 1100px; margin: 40px auto; padding: 20px; }
        .dashboard-stats { display: flex; gap: 20px; margin-bottom: 30px; }
        .stat-card { background: #fff; padding: 25px; flex: 1; border-radius: 12px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .stat-card p { font-size: 2.5em; margin: 10px 0 0 0; font-weight: bold; color: var(--dark); }

        .admin-table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .admin-table th { background: var(--dark); color: #fff; padding: 15px; text-align: left; }
        .admin-table td { padding: 15px; border-bottom: 1px solid #eee; }
        
        .btn { border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; font-weight: bold; color: white; }
        .btn-approve { background: var(--green); }
        .btn-reject { background: #e74c3c; }
        .status-badge { padding: 5px 10px; border-radius: 20px; font-size: 0.8em; font-weight: bold; }
        .status-Pending { background: #f1c40f; color: #fff; }
        .status-Approved { background: var(--green); color: #fff; }
    </style>
</head>
<body>
<nav class="admin-nav">
    <div class="nav-container">
        <?php $current = basename($_SERVER['PHP_SELF']); ?>
        <a href="admin_dashboard.php" class="<?= $current == 'admin_dashboard.php' ? 'active' : '' ?>">Dashboard</a>
        <a href="rooms.php" class="<?= $current == 'rooms.php' ? 'active' : '' ?>">Rooms</a>
        <a href="admin_bookings.php" class="<?= $current == 'admin_bookings.php' ? 'active' : '' ?>">Bookings</a>
    </div>
</nav>