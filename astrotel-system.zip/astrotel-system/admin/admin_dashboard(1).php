<?php 
include '../config/db.php'; 
include 'admin_header.php'; 

$total = $conn->query("SELECT COUNT(*) FROM reservations")->fetchColumn();
$pending = $conn->query("SELECT COUNT(*) FROM reservations WHERE status = 'Pending'")->fetchColumn();
$avail = $conn->query("SELECT COUNT(*) FROM rooms WHERE status = 'Available'")->fetchColumn();
?>
<div class="admin-content">
    <h2>Admin Dashboard</h2>
    <div class="dashboard-stats">
        <div class="stat-card"><h3>Total Bookings</h3><p><?= $total ?></p></div>
        <div class="stat-card"><h3>Pending</h3><p style="color:#f39c12"><?= $pending ?></p></div>
        <div class="stat-card"><h3>Available Rooms</h3><p style="color:#2ecc71"><?= $avail ?></p></div>
    </div>
</div>